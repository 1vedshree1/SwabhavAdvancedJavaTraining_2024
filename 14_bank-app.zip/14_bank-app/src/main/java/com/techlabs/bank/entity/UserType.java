package com.techlabs.bank.entity;

public enum UserType {
	
	ADMIN,CUSTOMER

}
