package com.techlabs.bank.entity;

public enum AccountType {
	
	SAVING, CURRENT

}
