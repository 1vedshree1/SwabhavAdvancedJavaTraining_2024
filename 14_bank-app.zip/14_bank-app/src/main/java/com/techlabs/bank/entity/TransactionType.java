package com.techlabs.bank.entity;

public enum TransactionType {

	CREDIT,DEBIT
}
